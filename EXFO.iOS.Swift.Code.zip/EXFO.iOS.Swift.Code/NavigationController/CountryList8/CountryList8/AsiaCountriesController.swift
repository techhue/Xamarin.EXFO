//
//  AsiaCountriesController.swift
//  CountryList8
//
//  Created by Nagarajan on 8/28/14.
//  Copyright (c) 2014 Nagarajan. All rights reserved.
//

import UIKit

class AsiaCountriesController: CountryListController {
    
    var countryList:[String] = ["Afghanistan", "Bahrain", "Bangladesh", "Bhutan",
        "Brunei", "Cambodia", "China", "East Timor", "India",
        "Indonesia", "Iran", "Iraq", "Israel", "Japan", "Jordan",
        "Kazakhstan", "Korea North", "Korea South", "Kuwait", "Kyrgyzstan",
        "Laos", "Lebanon", "Malaysia", "Maldives", "Mongolia", "Myanmar (Burma)",
        "Nepal", "Oman", "Pakistan", "The Philippines", "Qatar", "Russia",
        "Saudi Arabia", "Singapore", "Sri Lanka", "Syria", "Taiwan", "Tajikistan",
        "Thailand", "Turkey", "Turkmenistan", "United Arab Emirates", "Uzbekistan",
        "Vietnam", "Yemen"]
    
    let cellIdentifier = "CountryCell"
    
    convenience init()
    {
        self.init(style: UITableViewStyle.Plain)
        self.title = "Asia Countries"
        self.rowImage = UIImage(named: "map.jpg")
    }
    

    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override init(style: UITableViewStyle) {
        super.init(style: UITableViewStyle.Plain)
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return 1;
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.countryList.count
    }
    
    func configureCell(cell: UITableViewCell, indexPath: NSIndexPath)
    {
        cell.textLabel?.text = self.countryList[indexPath.row]
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        var cell = tableView.dequeueReusableCellWithIdentifier(self.cellIdentifier)
        if cell == nil
        {
            cell = UITableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier: self.cellIdentifier)
        }
        configureCell(cell!, indexPath: indexPath)
        
        var count = 0
        if (self.tableView.editing && indexPath.row != 0)
        {
            count = 1
        }
        if(indexPath.row == (self.countryList.count) && self.tableView.editing)
        {
            cell!.textLabel?.text = "Add a new Cell"
            return cell!
        }

        
        return cell!
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue!, sender: AnyObject!) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func editTable()
    {
        if(self.tableView.editing)
        {
            self.tableView.setEditing(false, animated: false)
            self.tableView.reloadData()
            /*var button:UIButton = self.view.subviews[1] as UIButton
            button.setTitle("Edit", forState: .Normal)*/
        }
        else
        {
            self.tableView.setEditing(true, animated: true)
            self.tableView.reloadData()
            /*var button:UIButton = self.view.subviews[1] as UIButton
            button.setTitle("Done", forState: .Normal)*/
        }
    }
    
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool
    {
        return true
    }
    
    override func tableView(tableView: UITableView, editingStyleForRowAtIndexPath indexPath: NSIndexPath?) -> UITableViewCellEditingStyle
    {
        if(self.tableView?.editing == false || indexPath == nil)
        {
            return UITableViewCellEditingStyle.None
        }
        else if(self.tableView.editing && indexPath?.row == self.countryList.count)
        {
            return UITableViewCellEditingStyle.Insert
        }
        else
        {
            return UITableViewCellEditingStyle.Delete
        }
    }
    
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath)
    {
        if(editingStyle == UITableViewCellEditingStyle.Delete)
        {
            self.countryList.removeAtIndex(indexPath.row)
            self.tableView.reloadData()
        }
        else if(editingStyle == UITableViewCellEditingStyle.Insert)
        {
            self.countryList.insert("New Country", atIndex: self.countryList.count)
            self.tableView.reloadData()
        }
    }
    
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool
    {
        return true
    }
    
    override func tableView(tableView: UITableView, moveRowAtIndexPath sourceIndexPath: NSIndexPath, toIndexPath destinationIndexPath: NSIndexPath)
    {
        let obj = self.countryList[sourceIndexPath.row]
        self.countryList.removeAtIndex(sourceIndexPath.row)
        self.countryList.insert(obj, atIndex: destinationIndexPath.row)
    }


}
