//
//  ViewController.swift
//  CustomViewController
//
//  Created by Nagarajan on 8/27/14.
//  Copyright (c) 2014 Nagarajan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var contentView:UIView?
    var tabBarView:UIView?
    var firstTab:UIView?
    var secondTab:UIView?
    var firstTabController:FirstTabController?
    var secondTabController:SecondTabController?
    
    override func loadView()
    {
        super.loadView()
    }
                            
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.firstTabController = FirstTabController()
        self.secondTabController = SecondTabController()
        configureContentView()
        configureTabBarView()
        configureFirstTabView()
        configureSecondTabView()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func configureFirstTabView()
    {
        self.firstTab = UIView(frame: CGRectMake(self.tabBarView!.bounds.origin.x,
            self.tabBarView!.bounds.origin.y,
            self.tabBarView!.bounds.size.width/2,
            self.tabBarView!.bounds.size.height))
        self.firstTab!.backgroundColor = UIColor.orangeColor()
        
        let tabTitle = UILabel(frame: CGRectMake(0, 0, 100, 30))
        tabTitle.text = self.firstTabController!.title
        configureTitleLabel(tabTitle)
        self.firstTab!.addSubview(tabTitle)
        self.tabBarView!.addSubview(self.firstTab!)
        
        let singTap = UITapGestureRecognizer(target: self, action: "handleFirstTabGesture:")
        singTap.numberOfTapsRequired = 1
        singTap.numberOfTouchesRequired = 1
        self.firstTab!.addGestureRecognizer(singTap)
    }
    
    func configureSecondTabView()
    {
        self.secondTab = UIView(frame: CGRectMake(self.tabBarView!.bounds.size.width/2,
            self.tabBarView!.bounds.origin.y,
            self.tabBarView!.bounds.size.width/2,
            self.tabBarView!.bounds.size.height))
        self.secondTab!.backgroundColor = UIColor.magentaColor()
        
        let tabTitle = UILabel(frame: CGRectMake(0, 0, 100, 30))
        tabTitle.text = self.secondTabController!.title
        configureTitleLabel(tabTitle)
        self.secondTab!.addSubview(tabTitle)
        self.tabBarView!.addSubview(self.secondTab!)
        
        let singTap = UITapGestureRecognizer(target: self, action: "handleSecondTabGesture:")
        singTap.numberOfTapsRequired = 1
        singTap.numberOfTouchesRequired = 1
        self.secondTab!.addGestureRecognizer(singTap)
    }
    
    func configureContentView()
    {
        self.contentView = UIView(frame: CGRectMake(self.view.bounds.origin.x,
            self.view.bounds.origin.y,
            self.view.bounds.size.width,
            self.view.bounds.size.height - 50))
        self.contentView!.backgroundColor = UIColor.brownColor()
        self.view.addSubview(self.contentView!)
    }
    
    func configureTabBarView()
    {
        self.tabBarView = UIView(frame: CGRectMake(self.view.bounds.origin.x,
            self.view.bounds.size.height - 50,
            self.view.bounds.size.width,
            50))
        self.tabBarView!.backgroundColor = UIColor.lightGrayColor()
        self.view.addSubview(self.tabBarView!)
    }
    
    func configureTitleLabel(label:UILabel)
    {
        label.textColor = UIColor.whiteColor()
        label.font = UIFont.systemFontOfSize(14)
        label.textAlignment = NSTextAlignment.Center
        label.backgroundColor = UIColor.clearColor()
    }
    
    func handleFirstTabGesture(recognizer: UITapGestureRecognizer)
    {
        self.secondTabController!.willMoveToParentViewController(nil)
        self.secondTabController!.view.removeFromSuperview()
        self.secondTabController!.removeFromParentViewController()
        
        self.addChildViewController(self.firstTabController!)
        self.firstTabController!.view.frame = self.contentView!.frame
        self.contentView!.addSubview(self.firstTabController!.view)
        self.firstTabController!.didMoveToParentViewController(self)
    }
    
    func handleSecondTabGesture(recognizer:UITapGestureRecognizer)
    {
        self.firstTabController!.willMoveToParentViewController(nil)
        self.firstTabController!.view.removeFromSuperview()
        self.firstTabController!.removeFromParentViewController()
        
        self.addChildViewController(self.secondTabController!)
        self.secondTabController!.view.frame = self.contentView!.frame
        self.contentView!.addSubview(self.secondTabController!.view)
        self.secondTabController!.didMoveToParentViewController(self)
    }

}

