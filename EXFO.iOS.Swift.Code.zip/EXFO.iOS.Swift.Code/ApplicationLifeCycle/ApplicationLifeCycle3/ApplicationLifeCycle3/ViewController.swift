//
//  ViewController.swift
//  ApplicationLifeCycle3
//
//  Created by Nagarajan on 8/28/14.
//  Copyright (c) 2014 Nagarajan. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate
{
    
    var question: UITextField?
    var answer: UITextField?
    
    override func loadView()
    {
        super.loadView()
        
        self.question = UITextField(frame: CGRectMake(10, 50, self.view.bounds.size.width-20, 30))
        self.question!.borderStyle = UITextBorderStyle.RoundedRect
        self.question!.font = UIFont.systemFontOfSize(15)
        self.question!.placeholder = "Enter the question"
        self.question!.autocorrectionType = UITextAutocorrectionType.No
        self.question!.keyboardType = UIKeyboardType.Default
        self.question!.returnKeyType = UIReturnKeyType.Done
        self.question!.clearButtonMode = UITextFieldViewMode.WhileEditing
        self.question!.contentVerticalAlignment = UIControlContentVerticalAlignment.Center
        self.question!.delegate = self
        self.view.addSubview(self.question!)
        
        self.answer = UITextField(frame: CGRectMake(10, 100, self.view.bounds.size.width-20, 30))
        self.answer!.borderStyle = UITextBorderStyle.RoundedRect
        self.answer!.font = UIFont.systemFontOfSize(15)
        self.answer!.placeholder = "Enter the answer"
        self.answer!.autocorrectionType = UITextAutocorrectionType.No
        self.answer!.keyboardType = UIKeyboardType.Default
        self.answer!.returnKeyType = UIReturnKeyType.Done
        self.answer!.clearButtonMode = UITextFieldViewMode.WhileEditing
        self.answer!.contentVerticalAlignment = UIControlContentVerticalAlignment.Center
        self.answer!.delegate = self
        self.view.addSubview(self.answer!)
    }
                            
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool
    {
        textField.resignFirstResponder()
        return true
    }


}

